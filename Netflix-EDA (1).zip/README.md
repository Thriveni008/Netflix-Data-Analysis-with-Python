# 🎬 Netflix Data Analysis

This project analyzes the Netflix dataset to uncover insights about content type distribution, popular genres, and release trends using Python.

## 🔍 Key Findings
- Majority of content is Movies (~70%)
- Sharp increase in content additions after 2017
- Drama and International content are among the most frequent genres

## 📊 Tools & Libraries
- Python
- Pandas
- Matplotlib
- Seaborn
- Jupyter Notebook

## 📁 Dataset
Source: [Netflix Dataset on Kaggle](https://www.kaggle.com/datasets/shivamb/netflix-shows)

## ▶️ How to Run
1. Clone this repo
2. Install dependencies: `pip install -r requirements.txt`
3. Open `netflix_analysis.ipynb` in Jupyter and run the cells

---

Feel free to contribute or explore other datasets!
